package com.hand.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hand.mappers.UserserviceImpl;
import com.hand.pojo.User;
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String name = request.getParameter("userid");
		String password = request.getParameter("password");
		String sex = request.getParameter("sex");
		int age = Integer.parseInt(request.getParameter("age"));
		String telephone=request.getParameter("user_number");
		String creationdate = request.getParameter("creation_date");
		String updatetime = request.getParameter("last_update_date");
		String comments = request.getParameter("comments");
		User user = new User();
		user.setUser_name(name);
		user.setPassword(password);
		user.setAge(age);
		user.setCreationdate(creationdate);
		user.setTelephone(telephone);
		user.setComments(comments);
		UserserviceImpl userImpl = new UserserviceImpl();
		String url = "";
		try {
			System.out.println(name);
			System.out.println(password);
			user = userImpl.login(name, password);
			
			url = "message.jsp";
			request.getRequestDispatcher(url).forward(request, response);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			response.sendRedirect("login.jsp");
		}
		session.setAttribute("user", user);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
