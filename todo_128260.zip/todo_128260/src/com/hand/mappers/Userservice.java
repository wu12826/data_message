package com.hand.mappers;

import com.hand.pojo.User;

public interface Userservice {
	void register(User user) ;
	User login(String name,String password) ;
}
