package com.hand.mappers;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import com.hand.pojo.User;
import com.hand.utils.MyBatisSqlSessionFactory;

public class UserserviceImpl implements Userservice{

	@Override
	public void register(User user) {
//		SqlSession session = MyBatisSqlSessionFactory.openSession();
//		UserDao dao = session.getMapper(UserDao.class);
//		User name = dao.findByName(user.getName());
//		try {
//			if(name==null){
//				dao.saveUser(user);
//				session.commit();
//			}
//			else {
//				throw new Exception("�û����Ѿ�����");
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			
//		}	
	}

	@Override
	@Test
	public User login(String name, String password) {
		SqlSession session = MyBatisSqlSessionFactory.openSession();
	   UserDao mapper = session.getMapper(UserDao.class);
		User  user= mapper.findByName(name);
	    System.out.println(user.getUser_name());
		System.out.println(user.getPassword());
		System.out.println(user.getId());
		System.out.println(user.getSex());
		
		if(user.getUser_name().equals(name)&&user.getPassword().equals(password)){
			return user;
		}
		return null;
	}
}
