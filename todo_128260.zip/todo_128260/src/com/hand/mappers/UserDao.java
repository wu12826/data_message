package com.hand.mappers;

import com.hand.pojo.User;

public interface  UserDao {
	public User findByName(String user_name);
	public User findById(String id);
	public void saveUser(User user);
}

